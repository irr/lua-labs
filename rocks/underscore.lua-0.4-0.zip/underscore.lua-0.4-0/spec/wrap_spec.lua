require 'luaspec'

describe["_.map"] = function()
	before = function()
	end
	
	it["should"] = function()
	end
end